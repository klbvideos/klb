# -*- coding: utf-8 -*-
from .. import BaseSolver
from core.libs import *


class CaptchaSolver(BaseSolver):
    v2html = """
<html>
    <head>
        <script src="https://www.google.com/recaptcha/api.js?render=explicit"></script>
    </head>
    <body>
        <div id="gcon"></div>
        <script>
            grecaptcha.ready(
                function() {
                    grecaptcha.render(
                        gcon,  
                        {
                            sitekey: '%s', 
                            callback: function(token) {
                                python.sendResponse(token);
                            }
                        }
                    );
                }
            );
        </script>
    </body>
</html>"""

    v3html_action = """
<html>
    <head>
        <script src="https://www.google.com/recaptcha/api.js?render=%s"></script>
    </head>
    <body>
        <div id="gcon"></div>
        <script>
            grecaptcha.ready(
                function() {
                    grecaptcha.execute(
                        '%s',  
                        {
                            action: '%s', 
                        }
                    ).then(
                        function(token) {
                            python.sendResponse(token);
                        }
                    )
                }
            );
        </script>
    </body>
</html>"""

    v3html = """
    <html>
        <head>
            <script src="https://www.google.com/recaptcha/api.js?render=%s"></script>
        </head>
        <body>
            <div id="gcon"></div>
            <script>
                grecaptcha.ready(
                    function() {
                        grecaptcha.execute(
                            '%s'
                        ).then(
                            function(token) {
                                python.sendResponse(token);
                            }
                        )
                    }
                );
            </script>
        </body>
    </html>"""

    def __init__(self, *args, **kwargs):
        BaseSolver.__init__(self, *args, **kwargs)
        self.progress_dialog = False
        self.request = {}

    def get_balance(self):
        return 1

    def is_enabled(self):
        if not settings.get_setting('enabled', __file__):
            return False
        return True

    def solve_v3(self, site_url, site_key, action, min_score):
        self.request = {
            "html": self.v3html_action % (site_key, site_key, action) if action else self.v3html % (site_key, site_key),
            "url": site_url,
            "description": "Resolviendo reCAPTCHA v3",
            "ui": False
        }

    def solve_v2(self, site_url, site_key):
        self.request = {
            "html": self.v2html % site_key,
            "url": site_url,
            "description": "Resolviendo reCAPTCHA v2",
        }

    def get_response(self):
        from core.app import AndroidAPP
        app = AndroidAPP()
        app.run(self.request)

        self.result = app.response
