# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if "404 File not found!" in data:
        return ResolveError(0)

    """
    for url, type, res in scrapertools.find_multiple_matches(data, 'src: "([^"]+)", type: "([^"]+)", res: (\d+)'):
        itemlist.append(Video(url=url, res=res + 'p', type=type.replace('video/','').capitalize()))
    """

    source = jsontools.load_js(scrapertools.find_single_match(data, r'sources: (\[.*?\])'))[0]
    if source:
        src = source['src'].split(',')
        base = src.pop(0).replace('https', 'http')
        r_360 = src.pop(0)
        r_720 = src.pop(0)
        itemlist.append(Video(url=base + r_360 + '/master.m3u8', res='360p'))
        itemlist.append(Video(url=base + r_720 + '/master.m3u8', res='720p'))

    return itemlist
