# -*- coding: utf-8 -*-
from core.libs import *
import js2py


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    item.subtitle = scrapertools.find_multiple_matches(data, '<track kind="captions" src="([^"]+)')
    packed = scrapertools.find_single_match(data, '<script type="[^-]+-text/javascript">eval(.*?)</script>')
    if packed:
        data = js2py.eval_js(packed)

    for url in scrapertools.find_multiple_matches(data, '{src:"([^"]+)'):
        itemlist.append(Video(url=url))

    return itemlist

