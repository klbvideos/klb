# -*- coding: utf-8 -*-
from core.libs import *
import xbmcgui
from distutils.version import LooseVersion


class ChangeLog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.title = 'Registro de Cambios'
        self.ready = False
        try:
            data = six.ensure_str(open(os.path.join(sysinfo.runtime_path, 'changelog.txt'), 'rb').read())
        except Exception:
            logger.error()
        else:
            try:
                registro = re.compile(r'\[([\d.]+)\]\s*\t*-\s*\t*([0-9/]+)([^$\[]+)').findall(data)[0]
                self.version = registro[0].strip()
                self.fecha = registro[1].strip()
                self.cambios = registro[2].strip().replace('\t', '    ')
                if self.version == sysinfo.main_version:
                    self.ready = True
                else:
                    logger.debug('Versión %s not se encuentra en el registro' % sysinfo.main_version)
            except Exception:
                logger.error()

    def start(self):
        logger.trace()
        if not self.ready:
            return
        self.doModal()

    def onInit(self):
        logger.trace()
        if LooseVersion(xbmcgui.__version__) <= LooseVersion('2.2.5'):
            self.setCoordinateResolution(5)

        self.getControl(10002).setLabel(self.title)
        self.getControl(10004).setLabel("Versión:")
        self.getControl(10005).setLabel(self.version)
        self.getControl(10006).setLabel("Fecha:")
        self.getControl(10007).setLabel(self.fecha)
        self.getControl(10008).setLabel("Cambios:")
        self.getControl(10009).setText(self.cambios)
        self.setFocus(self.getControl(10003))

    def onClick(self, control):
        logger.trace()
        if control == 10003:
            self.close()
