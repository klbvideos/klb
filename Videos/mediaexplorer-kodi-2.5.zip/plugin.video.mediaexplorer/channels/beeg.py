# -*- coding: utf-8 -*-
from core.libs import *


def mainlist(item):
    logger.trace()

    itemlist = list()

    itemlist.append(item.clone(
        action='videos',
        label='Útimos videos',
        url='https://store.externulls.com/facts/index',
        limit=30,
        offset=0,
        content_type='videos'
    ))

    itemlist.append(item.clone(
        action='listcategorias',
        label='Listado categorias',
        url='https://store.externulls.com/tags/top',
        content_type='items'
    ))

    itemlist.append(item.clone(
        action='search',
        label='Buscar',
        content_type='items',
        category='adult',
        query=True
    ))

    return itemlist


def videos(item):
    logger.trace()
    itemlist = list()

    if '?' in item.url:
        url = '%s&limit=%s&offset=%s' % (item.url, item.limit, item.offset)
    else:
        url = '%s?limit=%s&offset=%s' % (item.url, item.limit, item.offset)

    json_data = jsontools.load_json(httptools.downloadpage(url).data)

    for video in json_data:
        if video['file'].get('set_id'):
            thumb = "https://thumbs-015.externulls.com/sets/%05d/thumbs/%05d-%04d.jpg" % (
                video['file']['set_id'],
                video['file']['set_id'],
                video['fc_facts'][0]['fc_thumbs'][0]
            )
        else:
            thumb = 'https://thumbs-015.externulls.com/videos/%s/%s.jpg' % (
                video['fc_file_id'],
                video['fc_facts'][0]['fc_thumbs'][0]
            )

        itemlist.append(item.clone(
            action='play',
            title=video['file']['stuff'].get('sf_name') or video['tags'][0]['tg_name'],
            file_id=video['fc_file_id'],
            thumb=thumb,
            folder=False,
            type='video',
            duration=video['file']['fl_duration']
        ))

    if len(json_data) == item.limit:
        itemlist.append(item.clone(
            action='videos',
            offset=item.offset + item.limit,
            type='next'
        ))

    return itemlist


def listcategorias(item):
    logger.trace()
    itemlist = list()

    json_data = jsontools.load_json(httptools.downloadpage(item.url).data)

    for tag in json_data:
        itemlist.append(item.clone(
            action='videos',
            label=tag['tg_name'],
            url='https://store.externulls.com/facts/tag?slug=' + tag['tg_slug'] + '&get_original=true',
            limit=30,
            offset=0,
            content_type='videos',
            type='item'
        ))

    return itemlist


def search(item):
    from lib import websocket
    logger.trace()
    itemlist = list()

    response = {}

    def on_message(ws, message):
        response['value'] = message
        ws.close()

    def on_open(ws):
        ws.send('{"type":"search","payload":{"Search_string":"' + item.query + '","offset":0,"limit":30}}')

    websocket.enableTrace(True)
    wss = websocket.WebSocketApp("wss://search.externulls.com/", on_open=on_open, on_message=on_message)

    wss.run_forever()

    while not response:
        time.sleep(0.5)

    json_data = jsontools.load_json(response['value'])

    for tag in json_data:
        itemlist.append(item.clone(
            action='videos',
            label=tag['tg_name'],
            url='https://store.externulls.com/facts/tag?slug=' + tag['tg_slug'] + '&get_original=true',
            limit=30,
            offset=0,
            content_type='videos',
            type='item'
        ))
    return itemlist


def play(item):
    logger.trace()
    itemlist = list()

    json_data = jsontools.load_json(
        httptools.downloadpage('https://store.externulls.com/facts/file/%s' % item.file_id).data
    )
    if not json_data['file'].get('resources'):
        for key, url in json_data['fc_facts'][0]['resources'].items():
            res = key.split('_')[-1] + 'p'
            itemlist.append(Video(url='https://video.beeg.com/' + url, res=res))
    else:
        for key, url in json_data['file']['resources'].items():
            res = key.split('_')[-1] + 'p'
            url = httptools.downloadpage(
                'https://video.beeg.com/' + url,
                follow_redirects=False,
                only_headers=True
            ).headers.get('location')
            itemlist.append(Video(url=url, res=res))

    return sorted(itemlist, key=lambda x: int(x.res[:-1]) if x.res else 0, reverse=True)
