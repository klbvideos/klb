# -*- coding: utf-8 -*-
from core.libs import *
import subprocess
import random
import ctypes
import socket
import segno
import base64
import threading
import select


def generate_id():
    """
    Función encargada de generar una ID aleatoria en caso de que no exista
    :return:
    """
    if not settings.get_setting('random_device_id', __file__):
        settings.set_setting('random_device_id', "MediaExplorer (%s)" % "%08x" % (random.getrandbits(32)), __file__)
    return settings.get_setting('random_device_id', __file__)


def config_menu(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Descargar APP para Android',
        action='download',
        url="https://www.mediaexplorer.tk/app/last"
    ))

    if os.name == 'nt':
        itemlist.append(item.clone(
            label='Auto configurar el Firewall de Windows',
            action='add_rules'
        ))

    itemlist.append(item.clone(
        label='Ajustes',
        action='config'
    ))

    return itemlist


def check_if_rule_exists():
    import subprocess
    si = subprocess.STARTUPINFO()
    si.dwFlags = 1
    si.wShowWindow = 0
    h = subprocess.Popen(
        'netsh advfirewall firewall show rule dir=in name=all verbose',
        stdout=subprocess.PIPE,
        shell=True,
        startupinfo=si
    )

    data = six.ensure_str(h.stdout.read(), 'cp437')
    udp_rule = None
    tcp_rule = None

    for rule in re.compile(r'(.*?\r\n-+.*?)\r\n\r\n', re.DOTALL).findall(data):
        r = [l.split("  ")[-1].strip() for l in rule.splitlines() if "  " in l]
        if len(r) == 16:
            line = 11
        else:
            line = 12
        if r[line].lower() == sys.executable.lower():
            if r[line - 4] == "UDP":
                udp_rule = r[0]
            else:
                tcp_rule = r[0]

    return udp_rule, tcp_rule


def add_rules(item):
    platformtools.dialog_ok('MediaExplorer', 'Para poder modificar las reglas del Firewall de Windows\n'
                                             'es necesario que des permiso cuando Windows te pregunte')

    dialog = platformtools.dialog_progress("MediaExplorer", "Añadiendo reglas...")
    udp, tcp = check_if_rule_exists()
    cmd_path = os.path.join(sysinfo.data_path, "firewall.cmd")
    command = ['@echo off']
    if udp:
        command.append(
            "netsh advfirewall firewall set rule name=%s dir=in protocol=UDP new enable=yes action=allow" % udp
        )

    else:
        command.append(
            'netsh advfirewall firewall add rule name=%s dir=in action=allow protocol=UDP enable=yes program="%s"' % (
                'Kodi',
                sys.executable
            )
        )

    if tcp:
        command.append(
            "netsh advfirewall firewall set rule name=%s dir=in protocol=TCP new enable=yes action=allow" % tcp
        )
    else:
        command.append(
            'netsh advfirewall firewall add rule name=%s dir=in action=allow protocol=TCP enable=yes program="%s"' % (
                'Kodi',
                sys.executable
            )
        )

    command.append("echo 1 > %s" % cmd_path.replace('.cmd', '.end'))
    open(cmd_path, "w").write('\n'.join(command))
    si = subprocess.STARTUPINFO()
    si.dwFlags = 1
    si.wShowWindow = 0
    subprocess.call(
        "powershell start -verb runas %s" % cmd_path,
        shell=True,
        startupinfo=si
    )

    start = time.time()
    dialog.update(50, 'Esperando confirmación...')
    while 'firewall.end' not in os.listdir(sysinfo.data_path) and time.time() - start < 10:
        time.sleep(0.2)

    os.remove(cmd_path)
    dialog.close()
    if os.path.exists(cmd_path.replace('.cmd', '.end')):
        os.remove(cmd_path.replace('.cmd', '.end'))
        platformtools.dialog_ok('MediaExplorer', 'Proceso realizado con éxito.')
    else:
        platformtools.dialog_ok('MediaExplorer', 'No se ha podido realizar el proceso.')


def download(item):
    qr_path = os.path.join(sysinfo.data_path, "qr_path.png")
    segno.make(item.url).save(qr_path, scale=20, border=1)
    platformtools.dialog_img_yesno(
        img=qr_path,
        heading="Descargar APP Android",
        message="Escanea el código QR para descargar la APP para android",
        no_show=False
    )
    if filetools.exists(qr_path):
        filetools.remove(qr_path)


def config(item):
    return platformtools.show_settings(item=item, title="Ajustes APP MediaExplorer Tools")


class StopThread(Thread):
    def __init__(self, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        self.setDaemon(True)
        self.killed = False

    def kill(self):
        try:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(self.ident, ctypes.py_object(SystemExit))
        except Exception:
            # Android no funciona así que se pasa al plan B
            self.killed = True
            self.join()


def killable_function(fnc):
    def runnable(self, *args, **kwargs):
        t = threading.current_thread()
        if hasattr(t, 'killed') and getattr(t, 'killed'):
            raise SystemExit()
        return fnc(self, *args, **kwargs)

    return runnable


class AndroidAPP:
    str_status = {
        'wait_connection': 'Abre la app MediaExplorer Tools\ny activa el Modo QR...',
        'searching': 'Abre la app MediaExplorer Tools\ny espera a que sea detectada...',

        'no_device': 'No se encuentra ningún dispositivo.',
        'no_selected': 'No se ha seleccionado ningún dispositivo.',

        'connecting': 'MediaExplorer Tools detectada.\nEstableciendo conexión...',
        'send_data': 'Conectado con MediaExplorer Tools.\nEnviando petición...',
        'wait_autorize': 'Conectado con MediaExplorer Tools.\nSigue las instrucciones de tu dispositivo.',
        'running': 'Conectado con MediaExplorer Tools.\nEjecutando petición...',
        'wait_user': 'Conectado con MediaExplorer Tools.\nSigue las instrucciones de tu dispositivo.',
        'wait_response': 'Conectado con MediaExplorer Tools.\nEsperando respuesta...',
        'send_response': 'Conectado con MediaExplorer Tools.\nRecibiendo respuesta...',

        'canceled': 'MediaExplorer Tools desconectada.\nPetición cancelada en el dispositivo.',
        'timeout': 'MediaExplorer Tools desconectada.\nTiempo de espera agotado.',
        'not_autorized': 'MediaExplorer Tools desconectada.\nPetición no aceptada.',
        'error': 'MediaExplorer Tools desconectada.\nSe ha producido un error en el dispositivo.',
        'connection_lost': 'MediaExplorer Tools desconectada.\nConexión perdida.',
        'unknow_error': 'MediaExplorer Tools\nSe ha producido un error: %s',
    }

    def __init__(self):
        self.return_value = None
        self.request = None
        self.sock = None
        self.is_qr = False
        self.response = None
        self.error = False
        self.thread = None
        self.dialog = None
        self.qr_path = os.path.join(sysinfo.data_path, "%08x.png" % (random.getrandbits(32)))
        self.avaiable_devices = {}
        self.host = ()

        if settings.get_setting("ip_mode", __file__) == 0:
            ip = self.get_lan_ip()
        else:
            ip = settings.get_setting("ip", __file__) or self.get_lan_ip()

        self.port = int(settings.get_setting("port", __file__))
        self.device_id = settings.get_setting("device_id", __file__)
        self.localhost = "%s:%s" % (ip, self.port)

        if settings.get_setting("search_mode", __file__) == 1:
            self.host = (settings.get_setting("host", __file__), self.port)

    @staticmethod
    def get_lan_ip():
        """
        Función encargada de obtener la ip LAN
        :return:
        """
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 53))
        return s.getsockname()[0]

    def new_thread(self):
        """
        Functión encargada de detener el Thread actual e iniciar uno nuevo (Para cambiar de modo)
        :return:
        """
        # Esperamos a que el Thread se tenga
        if self.thread:
            self.thread.kill()

        if self.sock:
            self.close_socket()

        # Creamos uno nuevo
        self.thread = StopThread(target=self._run)
        return self.thread

    def run(self, request):
        """
        Funcion encargada de iniciar el proceso
        :param request: dict
        :return: str
        """
        logger.trace()
        self.request = request
        self.request["device_id"] = self.device_id

        self.dialog = platformtools.dialog_app()
        self.new_thread().start()

        while not self.response:
            time.sleep(0.2)
            if self.dialog.canceled:
                logger.debug('Cancelando...')
                break

            if self.dialog.retry:
                logger.debug('Reintentando...')
                self.new_thread().start()
                self.dialog.retry = False

            if self.dialog.change:
                logger.debug('Cambiando modo...')
                self.change_mode()
                self.dialog.change = False

        if self.dialog:
            self.dialog.close()

        if self.thread:
            self.thread.kill()

        if self.sock:
            self.close_socket()

        if os.path.isfile(self.qr_path):
            os.remove(self.qr_path)

        return self.response

    # Functions
    def _run(self):
        """
        Función encargada de iniciar el proceso dependiendo de si es QR o Servidor
        :return:
        """

        try:
            self.hide_retry()
            if self.is_qr:
                self.change_state('wait_connection')  # Mostramos el mensaje
                self.listen()  # Ponemos el socket en escucha
                self.change_state('send_data')  # Mostramos el mensaje
                self.send_request()  # Enviamos solicitud
                self.change_state('wait_response')  # Mostramos el mensaje
                self.wait_response()  # Esperamos la respuesta del dispositivo
            else:
                self.change_state('searching')  # Mostramos el mensaje
                if self.discover_devices():  # Iniciamos búsqueda de dispositivos
                    self.change_state('connecting')  # Mostramos el mensaje
                    if self.select_device():  # Seleccionamos el dispositivo
                        self.connect()
                        self.change_state('send_data')  # Mostramos el mensaje
                        self.send_request()  # Enviamos solicitud
                        self.change_state('wait_response')  # Mostramos el mensaje
                        self.wait_response()  # Esperamos la respuesta del dispositivo
                    else:
                        self.change_state('no_selected')  # No se ha seleccionado ningun dispositivo
                        self.show_retry()
                else:  # Si NO se han encotrado dispositivos
                    self.change_state('no_device')  # No se ha encontrado ningun dispositivo
                    self.show_retry()
        except SystemExit:
            logger.debug("Thread killed")
            raise
        except Exception as e:
            logger.error()
            self.change_state('unknow_error', e)
            self.show_retry()
            raise

    @killable_function
    def is_socket_ready(self):
        if not self.sock:
            return False
        return bool(select.select([self.sock], [], [], 0.2)[0])

    @killable_function
    def discover_devices(self, timeout=None):
        """
        Función encargada de encontrar los dispositivos en la red
        :return: bool
        """
        if self.host:
            logger.debug("Dispositivo en modo manual: %s:%s, omitiendo búsqueda" % self.host)
            return True

        # Preparamos el socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(('', self.port))

        start = time.time()

        # Leemos los mensakes hasta que se agote el tiempo o se detenga el Thread
        while not timeout or time.time() - start < timeout:
            message = self.read(1024)
            if self.decode_message(message):  # Si hay mensaje y es correcto paramos de buscar
                break

        self.close_socket()
        logger.debug('Encontrados: %s' % self.avaiable_devices)
        return bool(self.avaiable_devices)

    @killable_function
    def select_device(self):
        if self.host:
            return True

        # Obtenemos los nombres de los dispositivos
        names = list(self.avaiable_devices.keys())

        if len(names) > 1:  # Si hay varios permitimos seleccionar uno
            index = platformtools.dialog_select("Selecciona un dispositivo", names)
        else:  # En caso contrario seleccionamos el único
            index = 0

        if index == -1:  # Si no se selecciona ninguno se cancela
            return False

        # Conectamos con el dispositivo
        device = names[index]
        self.host = (self.avaiable_devices[device]['host'], self.avaiable_devices[device]['port'])
        return True

    @killable_function
    def connect(self):
        logger.debug("Conectando a: %s:%s" % self.host)
        # Preparamos el socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect(self.host)

    @killable_function
    def send_request(self):
        # Enviamos datos
        self.send(jsontools.dump_json(self.request))

    @killable_function
    def wait_response(self):
        # Mientras la respuesta no llegue:
        while True:
            try:
                data = self.read()
            except SystemExit:
                raise
            except Exception:  # Se ha producido un error, probablemente la conexion cortada, terminamos.
                logger.error()
                self.change_state("connection_lost")
                self.close_socket()
                self.show_retry()

            else:  # Datos recibidos
                json_data = jsontools.load_json(data)

                # Si es una actialización de estado, la mostramos
                if json_data.get("status"):
                    self.change_state(json_data["status"])
                    if json_data['status'] in ('timeout', 'canceled'):
                        self.close_socket()
                        self.show_retry()
                        break

                # Si es un error, devolvemos el resultado
                elif json_data.get("error"):
                    self.response = json_data['value']
                    self.error = True
                    self.close_socket()
                    self.show_retry()
                    break

                # Devolvemos la respuesta
                else:
                    self.response = json_data['value']
                    self.error = False
                    self.close_socket()
                    self.dialog.close()
                    break

    @killable_function
    def decode_message(self, message):
        """
        Descodifica el mensaje Broadcast recibido del dispositivo
        :param message: str
        :return: bool
        """
        data = message.split('|')
        if len(data) != 4:
            return False
        if data[0] != 'com.mediaexplorer.tools':
            return False
        self.avaiable_devices[data[3]] = {'host': data[1], 'port': int(data[2])}
        logger.debug("Encontrado dispositivo '%s' (%s:%s)" % (data[3], data[1], data[2]))
        return True

    # Socket
    @killable_function
    def listen(self):
        """
        Pone el socket esperando una conexion entrante
        :return:
        """
        logger.debug("Escuchando en: %s" % self.port)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind(('', self.port))
        self.sock.listen(1)

        self.sock = self.accept()

    @killable_function
    def accept(self):
        while not self.is_socket_ready():
            continue
        connection, _ = self.sock.accept()
        self.close_socket()
        return connection

    def close_socket(self):
        """
        Cerramos el socket, notificandolo al cliente
        :return:
        """
        try:
            self.send('bye')
        except Exception:
            pass
        if self.sock:
            self.sock.close()
        self.sock = None

    def send(self, data):
        """
        Enviamos los datos por el socket
        :param data:
        :return:
        """
        data = six.ensure_binary(str(len(data))).rjust(10, b"0") + six.ensure_binary(data)
        self.sock.sendall(data)

    @killable_function
    def read(self, size=None):
        """
        Leemos los datos del socket
        :return:
        """

        while not self.is_socket_ready():
            pass

        if size is None:
            data = ''

            size = int(self.sock.recv(10))

            while len(data) < size:
                data += self.read(size - len(data))

            if data == 'bye':
                raise Exception(0, 'Connection reset')

            return data

        else:
            return six.ensure_str(self.sock.recv(size))

    # UI
    def change_state(self, state, value=None):
        """
        Actualizamos el mensaje de estado
        :param state: str
        :param value: str
        :return:
        """
        if value:
            logger.debug("Cambio de estado: %s, %s" % (state, value))
        else:
            logger.debug("Cambio de estado: %s" % state)
        if self.dialog:
            data = self.str_status.get(state, 'Desconocido...')
            if '%s' in data:
                self.dialog.change_state(data % value)
            else:
                self.dialog.change_state(data)

    def show_retry(self):
        """
        Mostramos el boton Reintentar
        :return:
        """
        if self.dialog:
            self.dialog.show_retry()

    def hide_retry(self):
        """
        Ocultamos el boton Reintentar
        :return:
        """
        if self.dialog:
            self.dialog.hide_retry()

    def change_mode(self):
        """
        Cambiamos de modo QR a modo Servidor
        :return:
        """
        if not self.is_qr:
            segno.make(base64.b64encode(six.ensure_binary(self.localhost))).save(self.qr_path, scale=20, border=1)
            self.dialog.show_qr(self.qr_path)
            self.dialog.set_qr_button("Modo Auto")
            self.hide_retry()
        else:
            self.dialog.hide_qr()
            self.dialog.set_qr_button("Modo QR")

        self.is_qr = not self.is_qr
        self.new_thread().start()
