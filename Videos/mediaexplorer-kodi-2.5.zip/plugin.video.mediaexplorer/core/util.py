# -*- coding: utf-8 -*-
from threading import Thread as _Thread
from core.libs import *
from platformcode import platformsettings


class Thread(_Thread):
    def __stop(self):
        try:
            logger.logger_object.end_thread()
        finally:
            _Thread.__stop(self)


class SysInfo:
    def __init__(self):
        self.runtime_path = platformsettings.runtime_path
        self.data_path = platformsettings.data_path
        self.temp_path = platformsettings.temp_path
        self.bookmarks_path = platformsettings.bookmarks_path
        self.os = sys.platform
        self.platform_name = platformsettings.platform_name
        self.platform_version = platformsettings.platform_version
        self.main_version = platformsettings.main_version
        self.py_version = '%d.%d.%d' % sys.version_info[0:3]
        self.profile = {}


class LimitResults:
    """
    Clase para limitar los resultados de una función deve usarse como decorator:
        @limit
        def contents(item):
            ---
    La función deve tener el formato estandard con un solo parametro "item" y devolver un itemlist.
    Si la función devuelve mas items del limite, los limita cortando el itemlist y añadiendo un item para pasar a la si
    guiente parte.
    Si la función devuelve menos items del limite y el ultimo item es para pasar a siguiente pagina, va pasando paginas
    hasta llegar al limite.
    """

    def __init__(self, fnc):
        """
        Inicializa la clase y establece la función.
        :param fnc: función a ejecutar
        """
        self.limit = 30
        self.deep_limit = 5
        self.deep = 0
        self.item = None
        self.next_item = None
        self.page_items = 0
        self.itemlist = []
        self.fnc = fnc

    def get_itemlist(self):
        """
        Obtiene los items llamando a la función y elimina el item de página siguiente.
        :return:
        """
        # Llamamos a la función con el item como argumento
        itemlist = self.fnc(self.item)

        # Eliminamos el item para pagina siguiente en caso de existir y lo guarda para usarlo mas adelante
        if itemlist and itemlist[-1].type == 'next':
            self.next_item = itemlist[-1].clone(index=None)
            itemlist = itemlist[:-1]
        else:
            self.next_item = None

        # Numero de items de la ultima llamada, utilizado para saber el indice por donde cortar en la siguiente pagina
        self.page_items = len(itemlist)
        self.itemlist.extend(itemlist)

    def fill_itemlist(self):
        """
        Realiza llamadas a la función hata que el itemlist tenga el tamaño adecuado.
        :return:
        """
        # Vamos pasando paginas mientras haya un item de 'Página siguiente' y el itemlist no llegue al tamaño indicado
        while True:
            # Contabilizamos la profundidad en el listado
            self.deep += 1

            # Llamamos a la función
            self.get_itemlist()

            # Si venimos de un itemlist cortado, eliminamos los primeros x elementos (los de las páginas anteriores)
            if self.item.index:
                self.itemlist = self.itemlist[self.item.index:]

            # Si el itemlist no esta lleno y hay mas paginas, continuamos con la siguiente
            if len(self.itemlist) < self.limit and self.next_item and self.deep < self.deep_limit:
                self.item = self.next_item
            else:
                break

    def limit_itemlist(self):
        """
        Corta el itemlist para no sobrepasar el limite de resultados, añade un item para pagina siguiente:
         - Si es una pagina siguiente real, pasa el item obtenido de la funcion (con una nueva url)
         - Si es una pagina siguiente virtual, pasa el ultimo item, con el index por donde cortar en la siguiente pagina
        :return:
        """

        # Si el itemlist es mayor que el limite:
        if len(self.itemlist) > self.limit:
            index = self.page_items - (len(self.itemlist) - self.limit)
            self.itemlist = self.itemlist[:self.limit]

            next_page = self.item.clone(type='next', index=index)
        else:
            next_page = self.next_item

        # Añadimos el item para pasar de pagina
        if next_page:
            self.itemlist.append(next_page)

    def __call__(self, arg):
        # Segunda llamada: Se ejecuta la función y limita el resultado
        self.deep = 0
        self.item = arg
        self.fill_itemlist()
        self.limit_itemlist()
        return self.itemlist


class ResolveProgress:
    messages = {
        0: 'Descargando datos...',
        1: 'Obteniendo enlaces...',
        2: 'Desencriptando enlaces...',
        3: 'Desempaquetando javascript...',
        4: 'Resolviendo captcha...'
    }

    def __init__(self, completed, message):
        if isinstance(message, int):
            self.message = self.messages.get(message, '')
        else:
            self.message = message
        self.completed = completed

    def __repr__(self):
        return 'ResolveProgress(%d, %s)' % (self.completed, self.message)


class ResolveError(Exception):
    messages = {
        0: 'El archivo no existe o ha sido eliminado.',
        1: 'El archivo está siendo procesado.',
        2: 'Es necesaria una cuenta premium para poder reproducir el vídeo.',
        3: 'Es necesario el uso de un debrider con este servidor.',
        4: 'Sobrepasado el límite de visualizaciones.',
        5: 'El vídeo no tiene un formato compatible.',
        6: 'No se ha encontrado ninguna url válida.',
        7: 'El captcha es incorrecto.',
        8: 'Se ha producido un error ejecutando el código JS.'
    }

    def __init__(self, code):
        if isinstance(code, int):
            Exception.__init__(self, self.messages[code])
            self.code = code
        else:
            Exception.__init__(self, code)
            self.code = None

    def __repr__(self):
        return repr(self.args[0])


class Resolver(Thread):
    """
    Clase Resolver deriva de Thread ejecuta 'get_video_url' en el modulo del servidor en otro thread y notifica el
    progreso.
    """

    def __init__(self, item, module, params):
        # Parametros: item, modulo importado del servidor, dict con los datos del servidor.
        self.item = item
        self.module = module
        self.params = params

        # Indica el modo de funcionamiento, servidores con funcion en modo 'generator' (actualizan el progreso) o
        # funciones normales (solo devuelven el resultado)
        self.mode = None

        # Indica si se ha cancelado el proceso
        self.canceled = False

        # Mensaje de progreso inicial
        self.progress = ResolveProgress(0, "Conectando con %s" % self.params["name"])

        # Ultima actualización de estado por parte del servidor
        self.last_update = 0

        # Ultimo reporte de estado por parte de Resolver
        self.last_report = 0

        # Inicializamos el Thread
        Thread.__init__(self, target=self.resolve)

    def _wait(self):
        """
        Espera hasta el proximo reporte de estado.
        El reporte se envía cada 0.25 segundo o si el servidor envía una actualización de estado
        :return:
        """
        while time.time() - self.last_report < 0.25 and self.last_update < self.last_report:
            time.sleep(0.1)
        self.last_report = time.time()

    def _set_progress(self, progress):
        """
        Establece el progreso para reportarlo, si el proceso está cancelado envia una Excepción para que el Thread se
        detenga
        :param progress:
        :return:
        """
        if self.canceled:
            raise SystemExit()

        self.progress = progress
        self.last_update = time.time()

    def start(self):
        """
        Inicia el proceso para resolver las url y va devolviendo el progreso cada 0,25 segundos
        :return:
        """
        # Iniciamos el Thread
        Thread.start(self)

        # Esperamos el que el thread esté iniciado y se establezca el modo de funcionamiento
        while self.mode is None:
            time.sleep(0.1)

        # Modo 0: La función devuelve un unico resultado al terminar, no tenemos actualizaiones así que no sabemos como
        #         va el proceso. En este caso damos un tiempo máximo (10s) para finalizar, y va aumentando la barra de
        #         progreso si no ha devuelto un resultado en ese tiempo se da por cancelado
        if self.mode == 0:
            # De 0 a 40
            for x in range(41):
                # Esperamos para la siguiente actualización
                self._wait()
                # Enviamos el progreso que en este caso es siempre el mismo pero actualizando el %
                yield ResolveProgress(int(x / 4.0 * 10), "Conectando con %s" % self.params["name"])

                # Si el progreso del servidor no es un ResolveProgres es que ya ha terminado
                if not isinstance(self.progress, ResolveProgress):
                    # Enviamos el resultado y terminamos
                    yield self.progress
                    return
            # Se han acabado los 10 segundo, cancelamos
            self.cancel()
        # Modo 1: El servidor va enviando progreso de estado, en este caso solo hay que reenviarlo
        else:
            # Mientras el progreso sea un ResolveProgress
            while isinstance(self.progress, ResolveProgress):
                # Esperamos a la siguiente actualización
                self._wait()
                # La enviamos.
                yield self.progress

    def resolve(self):
        """
        Ejecuta la función en el servidor para obtener la url
        :return:
        """
        logger.debug('Resolviendo: %s' % self.item.url)
        try:
            # Si la funcion es un 'generator'
            if inspect.isgeneratorfunction(self.module.get_video_url):
                # Modo 1
                self.mode = 1
                # Por cada actualización del servidor la almacenamos
                for status in self.module.get_video_url(self.item):
                    self._set_progress(status)
            # En caso contrario
            else:
                # Modo 0
                self.mode = 0
                # Almacenamos solo el retorno de la función
                self._set_progress(self.module.get_video_url(self.item))

        # Si se ha cancelado el progreso simplementa salimos sin mostrar ningun mensaje
        except SystemExit:
            return
        # Cualquier otro error, establecemos el progreso en Error y guardamos en el log
        except Exception:
            self._set_progress(ResolveError(6))
            logger.error()

    def cancel(self):
        """
        Cancela el proceso
        :return:
        """
        self.canceled = True


class ProxyDT(datetime.datetime):
    @classmethod
    def strptime(cls, date_string, _format):
        return datetime.datetime(*(time.strptime(date_string, _format)[0:6]))


def change_units(value):
    import math
    units = ["B", "KB", "MB", "GB"]
    if value <= 0:
        return "%.2f %s" % (0, units[0])
    else:
        return "%.2f %s" % (value / 1024.0 ** int(math.log(value, 1024)), units[int(math.log(value, 1024))])


def call_api(path, data=None):
    import random
    uuid = settings.get_setting('installation_id')
    if not uuid:
        settings.set_setting('installation_id', "%032x" % (random.getrandbits(128)))
        uuid = settings.get_setting('installation_id')

    if data is None:
        data = {'uid': uuid}
    else:
        data['uid'] = uuid
    return httptools.downloadpage(
        'http://api%d.mediaexplorer.tk/v1/%s%s' % (
            random.randint(0, 5),
            path,
            '?' + urllib_parse.urlencode(data) if data else ''
        ))


# Creamos sysinfo
sysinfo = SysInfo()
