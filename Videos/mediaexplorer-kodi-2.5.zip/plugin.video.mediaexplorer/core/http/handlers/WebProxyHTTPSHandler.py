# -*- coding: utf-8 -*-
from six.moves import urllib_request

from core.http.handlers import HTTPSHandler


class WebProxyHTTPSHandler(HTTPSHandler):
    """
    Clase HTTPS para usar servidores Web-Proxy
    """
    handler_order = 100

    def __init__(self, service, *args, **kwargs):
        urllib_request.HTTPSHandler.__init__(self, *args, **kwargs)
        self.service = service

    def https_open(self, req):
        return self.do_open(self.service, req, proto='https')
