from .handler import get_service

__all__ = ['get_service']
