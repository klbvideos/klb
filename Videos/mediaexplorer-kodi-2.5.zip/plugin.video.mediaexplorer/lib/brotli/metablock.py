# -*- coding: utf-8 -*-
import copy
import functools

from lib.brotli.values import NDBITS, DOFFSET, BROTLI_DICTIONARY, ILL, BLTYPE_CODES, LUT_2, LUT_1, LUT_0, BIT_LENGTHS, \
    TRANSFORMATIONS


class MetaBlock:
    def __init__(self, stream, output, window):
        self.ntreesd = None
        self.ntreesl = None
        self.cmode = None
        self.ndirect = None
        self.npostfix = None
        self.htreed = None
        self.htreei = None
        self.htreel = None
        self.clen = None
        self.ilen = None
        self.distance = None
        self.distance_code = None
        self.blend = None
        self.btyped = None
        self.htree_blend = None
        self.htree_btypesd = None
        self.nbltypesd = None
        self.nbltypesi = None
        self.htree_bleni = None
        self.htree_btypesi = None
        self.bleni = None
        self.btypei = None
        self.blenl = None
        self.btypel = None
        self.nbltypesl = None
        self.htree_blenl = None
        self.htree_btypesl = None
        self.isuncompressed = None
        self.mlen = None
        self.skiplen = None
        self.skip_bytes = None
        self.islast = None
        self.islastempty = None
        self.mnibles = None
        self.cmapl = None
        self.cmapd = None
        self.btypel_prev = 1
        self.btyped_prev = 1
        self.btypei_prev = 1
        self.window = window
        self.output = output
        self.distance_buf = [16, 15, 11, 4]
        self.distance_buf_pointer = 3
        self.meta_block_count_output = 0
        self.literal_buf = [0, 0]
        self.literal_buf_pointer = 0
        self.nsym = 0
        self.stream = stream

    def read(self):
        self.parse_is_last()

        self.parse_is_last_empty()
        if self.islast and self.islastempty:
            self.parse_remaining()
            return

        self.parse_mnibles()

        if self.mnibles == 0:
            self.parse_mnibles_skip_bytes()
            if self.skip_bytes == 0:
                self.parse_remaining()
                return
            self.parse_mnibles_parse_skip_len()
            self.parse_remaining()
        else:
            self.parse_mlen()
            self.parse_isuncompressed()

            if self.isuncompressed:
                self.parse_remaining()
                for literal in self.stream.read_bytes(self.mlen):
                    self.output.add(literal)
                    self.window.add(literal)
                    self.literal_buf_pointer = (self.literal_buf_pointer + 1) % 2
                    self.literal_buf[self.literal_buf_pointer] = literal
            else:
                self.parse_nbltypesl()
                self.parse_nbltypesi()
                self.parse_nbltypesd()
                self.parse_npostfix()
                self.parse_ndirect()
                self.parse_context_modes_literals()
                self.parse_ntreesl()

                if self.ntreesl >= 2:
                    self.parse_context_map_literals()
                else:
                    self.cmapl = [0] * (64 * self.nbltypesl)

                self.parse_ntreesd()
                if self.ntreesd >= 2:
                    self.parse_context_map_distances()
                else:
                    self.cmapd = [0] * (4 * self.nbltypesd)

                self.parse_prefix_codes_literals()
                self.parse_prefix_codes_insert_and_copy_lengths()
                self.parse_prefix_codes_distances()

                # Data Block Begin
                while self.mlen != self.meta_block_count_output:
                    self.parse_insert_and_copy_length()
                    if self.mlen != self.meta_block_count_output:
                        self.parse_distance_code()

    def parse_is_last(self):
        self.islast = self.stream.read_bit()

    def parse_is_last_empty(self):
        if self.islast:
            self.islastempty = self.stream.read_bit()

    def parse_remaining(self):
        if self.stream.read_remaining() != 0:
            raise Exception()

    def parse_mnibles(self):
        self.mnibles = {3: 0, 0: 4, 1: 5, 2: 6}[self.stream.read_u32(2)]

    def parse_mnibles_skip_bytes(self):
        if self.stream.read_bit() != 0:
            raise Exception()
        self.skip_bytes = self.stream.read_u32(2)

    def parse_mnibles_parse_skip_len(self):
        self.skiplen = self.stream.read_bytes(self.skip_bytes)
        if self.skiplen[-1] == 0:
            raise Exception()
        for i in range(self.skip_bytes):
            self.skiplen = self.skiplen | (self.skiplen[i] << i)

    def parse_mlen(self):
        self.mlen = functools.reduce(
            lambda i, x: i | functools.reduce(
                lambda z, y: z | self.stream.read_bit() << y,
                range(4),
                0
            ) << (4 * x),
            range(self.mnibles),
            0
        )

        self.mlen += 1

        if self.mnibles > 4 and (self.mlen >> ((self.mnibles - 1) * 4) == 0):
            raise Exception()

    def parse_isuncompressed(self):
        if not self.islast:
            self.isuncompressed = self.stream.read_bit()
        else:
            self.isuncompressed = 0

    def parse_nbltypesl(self):
        self.nbltypesl = self.parse_n_bltypes()
        if self.nbltypesl >= 2:
            self.htree_btypesl = self.parse_prefix_code(self.nbltypesl + 2)
            self.htree_blenl = self.parse_prefix_code(26)
            self.blenl = self.parse_block_count(self.htree_blenl)
            self.btypel = 0
        else:
            self.btypel = 0
            self.blenl = 1677216

    def parse_nbltypesi(self):
        self.nbltypesi = self.parse_n_bltypes()
        if self.nbltypesi >= 2:
            self.htree_btypesi = self.parse_prefix_code(self.nbltypesi + 2)
            self.htree_bleni = self.parse_prefix_code(26)
            self.bleni = self.parse_block_count(self.htree_bleni)
            self.btypei = 0
        else:
            self.btypei = 0
            self.bleni = 1677216

    def parse_nbltypesd(self):
        self.nbltypesd = self.parse_n_bltypes()
        if self.nbltypesd >= 2:
            self.htree_btypesd = self.parse_prefix_code(self.nbltypesd + 2)
            self.htree_blend = self.parse_prefix_code(26)
            self.blend = self.parse_block_count(self.htree_blend)
            self.btyped = 0
        else:
            self.btyped = 0
            self.blend = 1677216

    def parse_block_switch_command_d(self):
        block_type_code = self.lookup(self.htree_btypesd)

        if block_type_code == 0:
            block_type = self.btyped_prev
        elif block_type_code == 1:
            block_type = (self.btyped + 1) % self.nbltypesd
        elif 2 <= block_type_code <= 258:
            block_type = block_type_code - 2
        else:
            raise Exception()

        self.btyped_prev = self.btyped
        self.blend = self.parse_block_count(self.htree_blend)
        self.btyped = block_type

    def parse_block_switch_command_i(self):
        block_type_code = self.lookup(self.htree_btypesi)

        if block_type_code == 0:
            block_type = self.btypei_prev
        elif block_type_code == 1:
            block_type = (self.btypei + 1) % self.nbltypesi
        elif 2 <= block_type_code <= 258:
            block_type = block_type_code - 2
        else:
            raise Exception()

        self.btypei_prev = self.btypei
        self.bleni = self.parse_block_count(self.htree_bleni)
        self.btypei = block_type

    def parse_block_switch_command_l(self):
        block_type_code = self.lookup(self.htree_btypesl)

        if block_type_code == 0:
            block_type = self.btypel_prev
        elif block_type_code == 1:
            block_type = (self.btypel + 1) % self.nbltypesl
        elif 2 <= block_type_code <= 258:
            block_type = block_type_code - 2
        else:
            raise Exception()

        self.btypel_prev = self.btypel
        self.blenl = self.parse_block_count(self.htree_blenl)
        self.btypel = block_type

    def parse_distance_code(self):

        if self.distance_code == 0:
            self.distance_code = 0
        else:
            if self.blend == 0:
                self.parse_block_switch_command_d()

            self.blend -= 1

            if self.clen == 0 or self.clen == 1:
                raise Exception()
            elif self.clen == 2 or self.clen == 3 or self.clen == 4:
                cid = self.clen - 2
            else:
                cid = 3

            index = self.cmapd[self.btyped * 4 + cid]
            self.distance_code = self.lookup(self.htreed[index])

        if 0 <= self.distance_code <= 3:
            distance = self.distance_buf[(4 + self.distance_buf_pointer - self.distance_code) % 4]

        elif 4 <= self.distance_code <= 9:
            distance = self.distance_buf[self.distance_buf_pointer]
            sign = self.distance_code % 2
            d = (self.distance_code - 2) >> 1
            if sign:
                distance = distance + d
            else:
                if distance <= d:
                    raise Exception()
                distance = distance - d

        elif 10 <= self.distance_code <= 15:
            distance = self.distance_buf[(3 + self.distance_buf_pointer) % 4]
            sign = self.distance_code % 2
            d = (self.distance_code - 8) >> 1
            if sign:
                distance = distance + d
            else:
                if distance <= d:
                    raise Exception()
                distance = distance - d
        elif self.distance_code <= (15 + self.ndirect):
            distance = self.distance_code - 15
        else:

            ndistbits = 1 + ((self.distance_code - self.ndirect - 16) >> (self.npostfix + 1))
            dextra = self.stream.read_u32(ndistbits)
            hcode = (self.distance_code - self.ndirect - 16) >> self.npostfix

            postfix_mask = (1 << self.npostfix) - 1
            lcode = (self.distance_code - self.ndirect - 16) & postfix_mask
            offset = ((2 + (hcode & 1)) << ndistbits) - 4
            distance = ((offset + dextra) << self.npostfix) + lcode + self.ndirect + 1

        if self.distance_code > 0 and distance <= self.window.size and distance <= self.output.length:
            self.distance_buf_pointer = (self.distance_buf_pointer + 1) % 4
            self.distance_buf[self.distance_buf_pointer] = distance

        self.distance = distance

        max_allowed_distance = self.output.length
        if self.window.size < max_allowed_distance:
            max_allowed_distance = self.window.size

        if distance <= max_allowed_distance:
            literals = [self.window.get(distance - i) for i in range(self.clen)]
            for i in range(self.clen):
                literals[i] = literals[i % min(self.clen, distance)]
        else:
            if self.clen < 4 or self.clen > 24:
                raise Exception()

            word_id = distance - max_allowed_distance - 1

            if self.clen < 4:
                n_words_length = 0
            else:
                n_words_length = 1 << NDBITS[self.clen]

            index = word_id % n_words_length
            offset_from = DOFFSET[self.clen] + index * self.clen
            offset_to = DOFFSET[self.clen] + (index + 1) * self.clen
            base_word = [BROTLI_DICTIONARY[i + offset_from] for i in range(offset_to - offset_from)]

            transform_id = word_id >> NDBITS[self.clen]
            if transform_id > 120:
                raise Exception()

            literals = self.transformation(transform_id, base_word)

        if self.mlen < self.meta_block_count_output + len(literals):
            raise Exception()

        for literal in literals:
            self.output.add(literal)
            self.literal_buf_pointer = (self.literal_buf_pointer + 1) % 2
            self.literal_buf[self.literal_buf_pointer] = literal
            self.window.add(literal)

            self.meta_block_count_output += 1

    def parse_insert_and_copy_length(self):
        if self.bleni == 0:
            self.parse_block_switch_command_i()

        self.bleni -= 1

        length = self.lookup(self.htreei[self.btypei])

        if 0 <= length <= 127:
            self.distance_code = 0
        else:
            self.distance_code = None

        self.ilen = ILL[0 + length * 4] + self.stream.read_u32(ILL[1 + length * 4])
        self.clen = ILL[2 + length * 4] + self.stream.read_u32(ILL[3 + length * 4])

        if self.mlen < self.meta_block_count_output + self.ilen:
            raise Exception()

        literals = []
        for x in range(self.ilen):
            if self.blenl == 0:
                self.parse_block_switch_command_l()
            self.blenl -= 1

            context_mode = self.cmode[self.btypel]

            p1 = self.literal_buf[self.literal_buf_pointer]
            p2 = self.literal_buf[(self.literal_buf_pointer + 1) % 2]
            if context_mode == 0:
                cid = p1 & 63
            elif context_mode == 1:
                cid = p1 >> 2
            elif context_mode == 2:
                cid = LUT_0[p1] | LUT_1[p2]
            elif context_mode == 3:
                cid = (LUT_2[p1] << 3) | LUT_2[p2]
            else:
                raise Exception()

            index = self.cmapl[self.btypel * 64 + cid]

            literals.append(self.lookup(self.htreel[index]))
            self.literal_buf_pointer = (self.literal_buf_pointer + 1) % 2
            self.literal_buf[self.literal_buf_pointer] = literals[-1]

        if self.mlen < self.meta_block_count_output + self.ilen:
            raise Exception

        for literal in literals:
            self.output.add(literal)
            self.window.add(literal)
            self.meta_block_count_output += 1

    def parse_context_map_literals(self):
        self.cmapl = self.parse_context_map(self.ntreesl, self.nbltypesl * 64)

    def parse_context_map_distances(self):
        self.cmapd = self.parse_context_map(self.ntreesd, self.nbltypesd * 4)

    def parse_prefix_codes_literals(self):
        self.htreel = [self.parse_prefix_code(256) for _ in range(self.ntreesl)]

    def parse_prefix_codes_insert_and_copy_lengths(self):
        self.htreei = [self.parse_prefix_code(704) for _ in range(self.nbltypesi)]

    def parse_prefix_codes_distances(self):
        self.htreed = [self.parse_prefix_code(16 + self.ndirect + (48 << self.npostfix)) for _ in range(self.ntreesd)]

    def parse_context_map(self, n_trees, len_):
        rlemax = self.stream.read_bit()
        if rlemax:
            rlemax = self.stream.read_u32(4) + 1

        prefix_tree = self.parse_prefix_code(rlemax + n_trees)

        c_map = [None] * len_
        c_pushed = 0

        while c_pushed < len_:
            run_length_code = self.lookup(prefix_tree)
            if 0 < run_length_code <= rlemax:
                repeat = (1 << run_length_code) + self.stream.read_u32(run_length_code)
                j = 0
                while j < repeat:
                    c_map[c_pushed] = 0
                    c_pushed += 1
                    if c_pushed > len_:
                        raise Exception()
                    j += 1
            else:
                if run_length_code == 0:
                    c_map[c_pushed] = 0
                else:
                    c_map[c_pushed] = run_length_code - rlemax
                c_pushed += 1
        imtf_bit = self.stream.read_bit()
        if imtf_bit:
            self.inverse_move_to_front_transform(c_map)
        return c_map

    def parse_npostfix(self):
        self.npostfix = self.stream.read_u32(2)

    def parse_ndirect(self):
        self.ndirect = self.stream.read_u32(4) << self.npostfix

    def parse_context_modes_literals(self):
        self.cmode = [self.stream.read_u32(2) for _ in range(self.nbltypesl)]

    def parse_ntreesl(self):
        self.ntreesl = self.parse_n_bltypes()

    def parse_ntreesd(self):
        self.ntreesd = self.parse_n_bltypes()

    def parse_prefix_code(self, alphabet_size):
        prefix_code_kind = self.stream.read_u32(2)

        if prefix_code_kind == 1:
            return self.parse_simple_prefix_code(alphabet_size)

        return self.parse_complex_prefix_code(prefix_code_kind, alphabet_size)

    def parse_n_bltypes(self):
        value = self.lookup(BLTYPE_CODES)
        if value == 1 or value == 2:
            return value
        elif value == 3:
            return value + self.stream.read_u32(1)
        elif value == 5:
            return value + self.stream.read_u32(2)
        elif value == 9:
            return value + self.stream.read_u32(3)
        elif value == 17:
            return value + self.stream.read_u32(4)
        elif value == 33:
            return value + self.stream.read_u32(5)
        elif value == 65:
            return value + self.stream.read_u32(6)
        elif value == 129:
            return value + self.stream.read_u32(7)

    def lookup(self, tree):
        if tree[1] == 0:
            return None
        if tree[1] == 1:
            return tree[2]
        pseudo_code = 1
        while True:
            pseudo_code = (pseudo_code << 1) + self.stream.read_bit()
            index = pseudo_code - 1
            if index > len(tree[0]) - 1:
                raise Exception()
            if tree[0][index] is not None:
                return tree[0][index]

    def parse_simple_prefix_code(self, alphabet_size):
        bit_width = alphabet_size - 1
        n = 0
        if bit_width == 0:
            n = 16
        else:
            while True:
                if bit_width >= 32768:
                    break
                n += 1
                bit_width <<= 1
        bit_width = 16 - n

        n_sym = self.stream.read_u32(2) + 1
        symbols = [self.stream.read_u32(bit_width) for _ in range(n_sym)]
        if len(set(symbols)) != len(symbols):
            raise Exception()

        if n_sym == 1:
            code_lengths = [0]
        elif n_sym == 2:
            tmp_ = symbols[0]
            if tmp_ > symbols[1]:
                symbols[0] = symbols[1]
                symbols[1] = tmp_
            code_lengths = [1, 1]

        elif n_sym == 3:
            tmp_ = symbols[1]
            if tmp_ > symbols[2]:
                symbols[1] = symbols[2]
                symbols[2] = tmp_
            code_lengths = [1, 2, 2]
        elif n_sym == 4:
            tree_select = self.stream.read_bit()
            if tree_select == 0:
                i = 1
                while i < n_sym:
                    x = symbols[i]
                    j = i - 1
                    while j >= 0 and symbols[j] > x:
                        symbols[j + 1] = symbols[j]
                        j = j - 1
                    symbols[j + 1] = x
                    i += 1
                code_lengths = [2, 2, 2, 2]
            else:
                tmp_ = symbols[2]
                if tmp_ > symbols[3]:
                    symbols[2] = symbols[3]
                    symbols[3] = tmp_
                code_lengths = [1, 2, 3, 3]
        else:
            raise Exception()

        return self.codes_from_lengths_and_symbols(code_lengths, symbols)

    def codes_from_lengths_and_symbols(self, lengths, symbols):
        max_length = 0
        for i in range(len(lengths)):
            j = lengths[i]
            if j > max_length:
                max_length = j

        bl_count = [0] * (max_length + 1)
        for i in range(len(lengths)):
            j = lengths[i]
            bl_count[j] = bl_count[j] + 1

        code = 0
        next_code = [None] * (max_length + 1)
        next_code[0] = 0
        bits = 1
        while bits < max_length + 1:
            code = (code + bl_count[bits - 1]) << 1
            next_code[bits] = code
            bits += 1

        len_ = (1 << (max_length + 1)) - 1
        codes = [[None] * len_, 0, None]

        for i in range(len(lengths)):
            len_ = lengths[i]
            if len_ > 0 or max_length == 0:
                code = [(next_code[len_] >> (len_ - x - 1)) & 1 for x in range(len_)]
                self.insert(codes, code, symbols[i])
                next_code[len_] = next_code[len_] + 1
        return codes

    def parse_block_count(self, prefix_code):
        symbol = self.lookup(prefix_code)
        if 0 <= symbol <= 3:
            return 1 + (symbol << 2) + self.stream.read_u32(2)
        elif 4 <= symbol <= 7:
            return 17 + ((symbol - 4) << 3) + self.stream.read_u32(3)
        elif 8 <= symbol <= 11:
            return 49 + ((symbol - 8) << 4) + self.stream.read_u32(4)
        elif 12 <= symbol <= 15:
            return 113 + ((symbol - 12) << 5) + self.stream.read_u32(5)
        elif 16 <= symbol <= 17:
            return 241 + ((symbol - 16) << 6) + self.stream.read_u32(6)
        elif symbol == 18:
            return 369 + self.stream.read_u32(7)
        elif symbol == 19:
            return 497 + self.stream.read_u32(8)
        elif symbol == 20:
            return 753 + self.stream.read_u32(9)
        elif symbol == 21:
            return 1265 + self.stream.read_u32(10)
        elif symbol == 22:
            return 2289 + self.stream.read_u32(11)
        elif symbol == 23:
            return 4337 + self.stream.read_u32(12)
        elif symbol == 24:
            return 8433 + self.stream.read_u32(13)
        elif symbol == 25:
            return 16625 + self.stream.read_u32(24)
        else:
            raise Exception()

    def parse_complex_prefix_code(self, h_skip, alphabet_size):
        code_lengths = [0] * 18
        sum_ = 0
        len_non_zero_codelengths = 0
        i = h_skip
        while i < 18:
            code_length = self.lookup(BIT_LENGTHS)
            code_lengths[i] = code_length
            if code_length > 0:
                sum_ = sum_ + (32 >> code_length)
                len_non_zero_codelengths += 1
                if sum_ == 32:
                    break
                if sum_ > 32:
                    raise Exception()
            i += 1

        if len_non_zero_codelengths == 0:
            raise Exception()

        if len_non_zero_codelengths >= 2 and sum_ < 32:
            raise Exception()

        code_lengths = [
            code_lengths[4],
            code_lengths[0],
            code_lengths[1],
            code_lengths[2],
            code_lengths[3],
            code_lengths[5],
            code_lengths[7],
            code_lengths[9],
            code_lengths[10],
            code_lengths[11],
            code_lengths[12],
            code_lengths[13],
            code_lengths[14],
            code_lengths[15],
            code_lengths[16],
            code_lengths[17],
            code_lengths[8],
            code_lengths[6]
        ]

        symbols = [i for i in range(18)]
        prefix_code_code_lengths = self.codes_from_lengths_and_symbols(code_lengths, symbols)
        actual_code_lengths = [0] * alphabet_size
        sum_ = 0
        last_symbol = None
        last_repeat = None
        last_non_zero_codelength = 8
        i = 0
        while i < alphabet_size:
            code_length_code = self.lookup(prefix_code_code_lengths)

            if 0 <= code_length_code <= 15:
                actual_code_lengths[i] = code_length_code
                i += 1
                last_symbol = code_length_code
                last_repeat = None
                if code_length_code > 0:
                    last_non_zero_codelength = code_length_code
                    sum_ += 32768 >> code_length_code
                    if sum_ == 32768:
                        break
                    elif sum_ > 32768:
                        raise Exception()
            elif code_length_code == 16:
                extra_bits = self.stream.read_u32(2)
                if last_symbol == 16 and last_repeat is not None:
                    new_repeat = 4 * (last_repeat - 2) + extra_bits + 3
                    if i + new_repeat - last_repeat > alphabet_size:
                        raise Exception()
                    j = 0
                    while j < new_repeat - last_repeat:
                        actual_code_lengths[i] = last_non_zero_codelength
                        i += 1
                        sum_ += 32768 >> last_non_zero_codelength
                        j += 1
                    if sum_ == 32768:
                        break
                    elif sum_ > 32768:
                        raise Exception()
                    last_repeat = new_repeat
                else:
                    repeat = 3 + extra_bits
                    if i + repeat > alphabet_size:
                        raise Exception()
                    j = 0
                    while j < repeat:
                        actual_code_lengths[i] = last_non_zero_codelength
                        i += 1
                        sum_ += 32768 >> last_non_zero_codelength
                        j += 1
                    if sum_ == 32768:
                        break
                    elif sum_ > 32768:
                        raise Exception()
                    last_repeat = repeat
                last_symbol = 16
            elif code_length_code == 17:
                extra_bits = self.stream.read_u32(3)
                if last_symbol == 17 and last_repeat is not None:
                    new_repeat = (8 * (last_repeat - 2)) + extra_bits + 3
                    i += new_repeat - last_repeat
                    last_repeat = new_repeat
                else:
                    repeat = 3 + extra_bits
                    i += repeat
                    last_repeat = repeat
                if i > alphabet_size:
                    raise Exception()
                last_symbol = 17
            else:
                raise Exception()
        tmp_ = 0
        for i in range(alphabet_size):
            if actual_code_lengths[i] > 0:
                tmp_ += 1
        if tmp_ < 2:
            raise Exception()
        symbols = [i for i in range(len(actual_code_lengths))]
        return self.codes_from_lengths_and_symbols(actual_code_lengths, symbols)

    @staticmethod
    def inverse_move_to_front_transform(v):
        mtf = [i for i in range(256)]
        for i in range(len(v)):
            index = v[i]
            value = mtf[index]
            v[i] = value
            for j in range(index, 0, -1):
                mtf[j] = mtf[j - 1]
            mtf[0] = value

    @staticmethod
    def transformation(code, word):
        data = TRANSFORMATIONS[code]

        result = copy.copy(data['prefix'])
        if data['transform'] == 0:
            result.extend(word)
        elif data['transform'] == 1:
            word[0] = ord(chr(word[0]).upper())
            result.extend(word)
        elif data['transform'] == 2:
            result.extend([ord(chr(ch).upper()) for ch in word])
        elif 2 < data['transform'] < 12:
            result.extend(word[data['transform'] - 2:])
        elif 11 < data['transform'] < 21:
            result.extend(word[:-data['transform'] + 11])

        result.extend(data['suffix'])
        return result

    @staticmethod
    def insert(tree, code, symbol):
        tree[1] += 1
        tree[2] = symbol
        index = 0
        for i in range(len(code)):
            index = (index << 1) + code[i]
        index = (1 << len(code)) - 1 + index

        if index > len(tree[0]) - 1:
            raise Exception()

        tree[0][index] = symbol
