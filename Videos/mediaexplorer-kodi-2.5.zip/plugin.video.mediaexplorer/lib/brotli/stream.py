# -*- coding: utf-8 -*-
import functools


class Stream:
    def __init__(self, data):
        if hasattr(data, 'read'):
            self.data = data.read()
        else:
            self.data = data

        self.data = bytearray(self.data)
        self.pos = 0

    @property
    def byte(self):
        return int(self.pos / 8)

    @property
    def bit(self):
        return self.pos % 8

    def read_bit(self):
        bit = self.data[self.byte] >> self.bit & 1
        self.pos += 1
        return bit

    def read_byte(self):
        byte = self.data[self.byte]
        self.pos += 8
        return byte

    def read_remaining(self):
        return self.read_u32((8 - self.bit) % 8)

    def read_bytes(self, length):
        return [self.read_byte() for _ in range(length)]

    def read_u32(self, length):
        return functools.reduce(lambda z, y: z | self.read_bit() << y, range(length), 0)
