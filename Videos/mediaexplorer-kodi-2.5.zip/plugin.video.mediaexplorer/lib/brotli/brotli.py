# -*- coding: utf-8 -*-
from .output import OutputStream
from .stream import Stream
from .metablock import MetaBlock
from .values import VBITS
from .window import Window


class Brotli:
    def __init__(self, data):
        self.window = Window(0)
        self.vbits = None
        self.stream = Stream(data)
        self.output = OutputStream()

    def parse_vbits(self):
        pseudo_code = 0
        for _ in range(8):
            pseudo_code = (pseudo_code << 1) + self.stream.read_bit()
            if pseudo_code in VBITS:
                self.vbits = VBITS[pseudo_code]
                break
        if not self.vbits:
            raise Exception()

    def read(self):
        self.parse_vbits()
        self.window = Window((1 << self.vbits) - 16)

        while True:
            metablock = MetaBlock(self.stream, self.output, self.window)
            metablock.read()
            if metablock.islast:
                break
        return self.output.read()
