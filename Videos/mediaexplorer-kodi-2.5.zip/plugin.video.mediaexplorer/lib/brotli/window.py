# -*- coding: utf-8 -*-


class Window:
    def __init__(self, size):
        self.size = size
        self.pointer = 0
        self.data = [None] * size

    def add(self, literal):
        self.pointer = (self.pointer + 1) % self.size
        self.data[self.pointer] = literal

    def get(self, distance):
        return self.data[(self.pointer + self.size - distance + 1) % self.size]
