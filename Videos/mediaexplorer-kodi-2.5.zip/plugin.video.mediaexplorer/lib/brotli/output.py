# -*- coding: utf-8 -*-


class OutputStream:
    def __init__(self):
        self.bytes = []

    def add(self, byte):
        self.bytes.append(byte)

    @property
    def length(self):
        return len(self.bytes)

    def read(self):
        return str(bytearray(self.bytes))
